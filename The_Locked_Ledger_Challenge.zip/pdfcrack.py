import hashlib, struct, sys, time
from Crypto.Cipher import AES

PDF = 'ledger.pdf'
data = open(PDF, 'rb').read()

O = bytes.fromhex('27840181c28b98ba1a9eb4b5ef5c4999e43dd07aba05242f508800c3db782a0b')
U = bytes.fromhex('b39ad45859f5c7650219aba741e30d4d0021446990b9e4114071a4d9104984c1')
P = -1028
R = 4
L = 128
n = L // 8
ID = bytes.fromhex('0c26a16505826d1ddd4d4297378a0601')

PAD = bytes([
0x28,0xBF,0x4E,0x5E,0x4E,0x75,0x8A,0x41,0x64,0x00,0x4E,0x56,0xFF,0xFA,0x01,0x08,
0x2E,0x2E,0x00,0xB6,0xD0,0x68,0x3E,0x80,0x2F,0x0C,0xA9,0xFE,0x64,0x53,0x69,0x7A])

def pad(pw):
    pw = pw[:32]
    return pw + PAD[:32-len(pw)]

def compute_key(pw):
    if isinstance(pw, str):
        pw = pw.encode('utf-8')
    h = hashlib.md5()
    h.update(pad(pw))
    h.update(O)
    h.update(struct.pack('<i', P))
    h.update(ID)
    if R >= 4:
        # EncryptMetadata default true; nothing appended
        pass
    key = h.digest()
    if R >= 3:
        for _ in range(50):
            key = hashlib.md5(key[:n]).digest()
    return key[:n]

def check(pw):
    key = compute_key(pw)
    if R >= 3:
        md = hashlib.md5(pad(b'') + ID).digest()
    else:
        md = hashlib.md5(pad(b'') + ID).digest()
    enc = AES.new(key, AES.MODE_ECB).encrypt(md)
    return enc == U[:16]

def objkey(key, num, gen=0):
    ext = struct.pack('<i', num)[:3] + struct.pack('<i', gen)[:2]
    if AES is not None:
        ext = ext + b'sAlT'
    return hashlib.md5(key + ext).digest()[:min(n+5, 16)]

if __name__ == '__main__':
    # quick tests
    words = ['sharma','Sharma','accounts','account','ledger','audit','auditor','balance','invoice','salary','tally','tax','gst','password','123456','admin','finance','bank','cash','debit','credit','journal','voucher','reconciliation','bookkeeping','sharmaji','Sharma@123','ledger2025','tandav']
    for w in words:
        if check(w):
            print('FOUND', w)
            break
    else:
        print('none of quick list')
    fn = sys.argv[1] if len(sys.argv) > 1 else None
    if fn:
        t0=time.time(); c=0
        with open(fn, 'rb') as f:
            for line in f:
                w=line.rstrip(b'\r\n')
                if not w: continue
                c+=1
                if check(w):
                    print('FOUND', w, 'after', c)
                    break
        print('done', c, time.time()-t0)
