import hashlib, struct, time, sys
from Crypto.Cipher import AES
from multiprocessing import Pool, cpu_count

O = bytes.fromhex('27840181c28b98ba1a9eb4b5ef5c4999e43dd07aba05242f508800c3db782a0b')
U = bytes.fromhex('b39ad45859f5c7650219aba741e30d4d0021446990b9e4114071a4d9104984c1')
P = -1028
ID = bytes.fromhex('0c26a16505826d1ddd4d4297378a0601')
PAD = bytes([
0x28,0xBF,0x4E,0x5E,0x4E,0x75,0x8A,0x41,0x64,0x00,0x4E,0x56,0xFF,0xFA,0x01,0x08,
0x2E,0x2E,0x00,0xB6,0xD0,0x68,0x3E,0x80,0x2F,0x0C,0xA9,0xFE,0x64,0x53,0x69,0x7A])
PACKED_P = struct.pack('<i', P)
TARGET = U[:16]

def pad(pw):
    return (pw[:32] + PAD)[:32]

def check(pw):
    h = hashlib.md5(pad(pw) + O + PACKED_P + ID).digest()
    for _ in range(50):
        h = hashlib.md5(h).digest()
    md = hashlib.md5(PAD + ID).digest()
    return AES.new(h, AES.MODE_ECB).encrypt(md) == TARGET

def worker(chunk):
    for w in chunk:
        if check(w):
            return w
    return None

def gen_chunks(fn, ch):
    batch = []
    with open(fn, 'rb') as f:
        for line in f:
            w = line.rstrip(b'\r\n')
            if not w:
                continue
            batch.append(w)
            if len(batch) >= ch:
                yield batch
                batch = []
        if batch:
            yield batch

if __name__ == '__main__':
    fn = sys.argv[1]
    nproc = int(sys.argv[2]) if len(sys.argv) > 2 else max(1, cpu_count()-1)
    t0 = time.time()
    print('procs', nproc, flush=True)
    pool = Pool(nproc)
    found = None
    total = 0
    for i, res in enumerate(pool.imap_unordered(worker, gen_chunks(fn, 3000))):
        total += 3000
        if res:
            found = res
            print('FOUND', repr(res), 'at ~', total, flush=True)
            pool.terminate()
            break
        if i % 50 == 0:
            print('progress', total, round(time.time()-t0,1), flush=True)
    else:
        pool.close()
    pool.join()
    print('TOTAL ~', total, 'TIME', round(time.time()-t0,1), 'FOUND', repr(found))
